

if you want to run this program please change -> URL of database :: in -> "Receipt.java"

thank you very much
